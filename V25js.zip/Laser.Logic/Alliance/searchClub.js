const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
const database = require("../../Laser.Server/db")
const AllianceListMessage = require('./AllianceListMessage');
class SearchAlliancesMessage extends PiranhaMessage {
  constructor(c, d) {
    super(d);
    this.session = d;
    this.id = 0x37f4;
    this.version = 0x0;
    this.stream = new ByteStream(c);
  }
  async ["decode"]() {
    this.Name = this.stream.readString();
  }
  async ['process']() {
    const c = await database.searchClub(this.Name);
    new AllianceListMessage(this.session, c, this.Name).send();
  }
}
module.exports = SearchAlliancesMessage;
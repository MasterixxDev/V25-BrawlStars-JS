
const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
const BattleLogMessage = require("./BattleLogMessage")
class HomeBattleReplayMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.session = session
    this.id = 14114
    this.version = 0
    this.stream = new ByteStream(bytes)
  }

  async decode () {
    //idk
  }

  async ['process']() {
    new BattleLogMessage(this.session).send();
  }
}

module.exports = HomeBattleReplayMessage

const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

const database = require("../../Laser.Server/db")

const TeamMessage = require('./TeamMessage');
const Gameroom = require('../../Laser.Server/Gameroom');

const TeamGameStartingMessage = require('./TeamGameStartingMessage');
const MatchMakingStatusMessage = require('../../Laser.Logic/MatchMaking/MatchMakingStatusMessage');
const GameMatchmakingManager = require('../../Laser.Logic/GameMatchmakingManager');


class TeamSetMemberReadyMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session);
    this.session = session;
    this.id = 14355;
    this.version = 0;
    this.stream = new ByteStream(bytes);
  }

  async decode () {
    this.bool = this.stream.readBoolean();
  }

  async process () {
    const Instance = new Gameroom()
    const roomInfo = Instance.setPlayerReady(this.session.roomID, this.session.lowID, this.bool);
    if (roomInfo !== null){
      for (const ids of roomInfo.players) {
        new TeamMessage(this.session, roomInfo).sendLowID(ids.lowID)
      }
      let submited = 0
      for (const ids of roomInfo.players) {
        if (ids.ready) submited += 1;
      }
      if(submited == roomInfo.players.length){
        for (const ids of roomInfo.players) {
          new TeamGameStartingMessage(this.session, roomInfo.mapID).sendLowID(ids.lowID)
          GameMatchmakingManager.Enqueue(this.session, roomInfo.mapSlot);
        }
      }
    }
  }
}
module.exports = TeamSetMemberReadyMessage;

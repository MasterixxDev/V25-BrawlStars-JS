const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
//Servers Packet
const LoginFailedMessage = require("./LoginFailedMessage")
const LoginOKMessage = require("./LoginOKMessage")
const OwnHomeDataMessage = require("../Home/OwnHomeDataMessage")
//database Calling
const database = require("../../Laser.Server/db")
const crypto = require('crypto');
const config = require("../../config.json")
const Shop = require("../../Utils/Shop")

const MyAllianceMessage = require('../Alliance/MyAllianceMessage')
const AllianceStreamMessage = require('../Alliance/AllianceStreamMessage')
//const FriendListMessage = require('../Friends/FriendListMessage')
const fs = require('fs');

class LoginMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10101
    this.version = 0
    this.stream = new ByteStream(bytes);
  }

  async decode () {
    this.stream.readInt()
    this.session.lowID = this.stream.readInt()
    this.session.token = this.stream.readString()

    this.major = this.stream.readInt()
    this.minor = this.stream.readInt()
    this.build = this.stream.readInt()
    this.fingerprint_sha = this.stream.readString() 
    this.DeviceModel = this.stream.readString()
    this.isAndroid = this.stream.readVInt()
  }

  isHashValid (checkHash) {
    const validHashes = "0c7901240f1c21eec1cef729d0d41f58b3a9b7f6|f557ffdd9cfc4e4d0e418108f33083e4|d8a6db135a566b8b07cd7dcf2fd233d94ba1e76b46b18d93d7e66f0242d595f7".split("|")
    const hash = checkHash.split("|")
    if (validHashes[0] === hash[0]) return true

    if (hash.length != validHashes.length) return false
    if (validHashes[0] != hash[0] || 
      validHashes[1] != hash[1] || 
      validHashes[2] != hash[2]) return false

    return true
  }

  async process () {


    if (!this.session.token) {
      this.session.token = crypto.randomBytes(Math.ceil(36/2)).toString('hex').slice(0, 36);
      await database.createAccount(this.session.token);
    }

    const account = await database.getAccountToken(this.session.token);
    if(account == null) return await new LoginFailedMessage(this.session, `Ваш аккаунт не найден, нужно удалить данные об игре!`, 18).send();

    if (account.Shop.length === 0 || account.Shop[0].EndDate === undefined || Math.floor((new Date(account.Shop[0].EndDate) - new Date()) / 1000) <= 0) {
      account.Shop = new Shop().generateShop(account);
      await database.replaceValue(account.lowID, 'Shop', account.Shop);
    }
    

    const bannedList = await getBannedList();
    const bannedEntry = bannedList.find(vip => vip.ip === this.session.ip.replace(/:\d+$/, '') || vip.token === this.session.token || vip.token === this.session.lowID);
    if (bannedEntry) {
      return new LoginFailedMessage(this.session, bannedEntry.reason, 11).send();
    }
  
    this.session.lowID = account.lowID;
    this.session.Resources = account.Resources;
	
    const unlockCardsArray = Object.values(global.UnlockCards);
    if (unlockCardsArray.length > account.Brawlers.length) {
        unlockCardsArray.forEach((card, i) => {
            if (!account.Brawlers.some(brawler => brawler.cardID === card)) {
                account.Brawlers.push({
                    id: i,
                    cardID: card,
                    unlocked: i === 0,
                    level: 0,
                    points: 0,
                    trophies: 0
                });
            }
        });
        await database.replaceValue(this.session.lowID, 'Brawlers', account.Brawlers);
    }
    if(!account.Notification.find(e => e.ID === 79)){
      const filteredBrawlers = account.Brawlers
        .filter(brawler => brawler.trophies >= 550)
        .map(brawler => ({
            id: brawler.id,
            t: Math.round(brawler.trophies * 0.90)
        }));
      const Save2DB = account.Brawlers
        .map(brawler => ({
          ...brawler,
          trophies: brawler.trophies * 0.90
        }));
      account.Resources.Starpoints += account.Brawlers
        .filter(brawler => brawler.trophies >= 550)
        .reduce((sum, brawler) => sum + (brawler.trophies * 0.10), 0);
      if(filteredBrawlers.length > 0){
        account.Notification.push({
          ID: 79,
          index: account.Notification.length*2,
          claim: false,
          date: new Date(),
          text: '',
          type: 0,
          brawlers: filteredBrawlers
        })
        await database.replaceValue(this.session.lowID, 'Resources', account.Resources);
        account.Brawlers = Save2DB;
        await database.replaceValue(this.session.lowID, 'Brawlers', account.Brawlers);
        await database.replaceValue(this.session.lowID, 'Notification', account.Notification);
        account.Trophies = account.Brawlers.reduce((sum, brawler) => sum + parseInt(brawler.trophies), 0);
      }
    }
	
    await new LoginOKMessage(this.session).send();
    await new OwnHomeDataMessage(this.session, account).send();

    if (account.ClubID !== 0) {
      let gettingClub = await database.getClub(account.ClubID);
      if (gettingClub === null) return await database.replaceValue(this.session.lowID, 'ClubID', 0);
      if (!gettingClub.members.includes(this.session.lowID)) return await database.replaceValue(this.session.lowID, 'ClubID', 0);

      this.session.ClubRole = account.ClubRole;
      this.session.ClubID = account.ClubID;
      await new MyAllianceMessage(this.session, gettingClub, false).send();
      await new AllianceStreamMessage(this.session, gettingClub.msg).send()
    }

    async function getBannedList() {
      if (!getBannedList.bannedList) {
        const data = await fs.promises.readFile('./Laser.Server/banned.json', 'utf8');
        getBannedList.bannedList = JSON.parse(data);
      }
      return getBannedList.bannedList;
    }
  }
}


module.exports = LoginMessage
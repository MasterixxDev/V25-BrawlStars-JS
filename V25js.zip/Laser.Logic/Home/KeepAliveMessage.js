const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
//database Calling
const database = require("../../Laser.Server/db")

class KeepAliveMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.session = session
    this.id = 10108
    this.version = 0
    this.stream = new ByteStream(bytes)
  }

  async decode () {
    // this.Status = this.stream.readVInt()
  }

  async process () {
    //
  }
}

module.exports = KeepAliveMessage
